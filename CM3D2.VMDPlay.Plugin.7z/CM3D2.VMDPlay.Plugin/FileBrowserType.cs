namespace CM3D2.VMDPlay.Plugin
{
	public enum FileBrowserType
	{
		File,
		Directory
	}
}
